print("|cff00ff00[HealthPercent]|r Loaded successfully! Please make sure Nameplates are enabled in your Settings. Use /hpsize [number] to adjust the font size.")

local f = CreateFrame("Frame")

local boxes = {}
local timer = 0
local size = 12 


local function CreateBox(unit)
    local plate = C_NamePlate.GetNamePlateForUnit(unit)
    if not plate then
        return
    end

    if boxes[unit] then
        return
    end

    local box = CreateFrame("Frame", nil, UIParent)
    box:SetSize(80, 20)
    box.text = box:CreateFontString(nil, "OVERLAY")
    box.text:SetFont("Fonts\\FRIZQT__.TTF", size, "OUTLINE")
    box.text:SetPoint("CENTER")
    box.text:SetText("")
    box:SetPoint("BOTTOM", plate, "TOP", 0, -15)
    box.plate = plate
    box.unit = unit

    boxes[unit] = box
end

local function RemoveBox(unit)
    if boxes[unit] then
        boxes[unit]:Hide()
        boxes[unit] = nil
    end
end


f:RegisterEvent("ADDON_LOADED")
f:RegisterEvent("NAME_PLATE_UNIT_ADDED")
f:RegisterEvent("NAME_PLATE_UNIT_REMOVED")


f:SetScript("OnEvent", function(_, event, arg1)
    if event == "ADDON_LOADED" and arg1 == "HealthPercent" then
        if HealthPercentDB == nil then
            HealthPercentDB = { size = 12 }
        end
        size = HealthPercentDB.size
        
    elseif event == "NAME_PLATE_UNIT_ADDED" then
        CreateBox(arg1)
        
    elseif event == "NAME_PLATE_UNIT_REMOVED" then
        RemoveBox(arg1)
    end
end)


f:SetScript("OnUpdate", function(_, elapsed)
    timer = timer + elapsed

    if timer < 0.05 then
        return
    end

    timer = 0

    local remove = {}

    for unit, box in pairs(boxes) do
        local currentPlate = C_NamePlate.GetNamePlateForUnit(unit)

        if UnitExists(unit) and currentPlate then
            if box.plate ~= currentPlate then
                box.plate = currentPlate
                box:ClearAllPoints()
                box:SetPoint(
                    "BOTTOM",
                    currentPlate,
                    "TOP",
                    0,
                    5
                )
            end

            local showPercent = false
        
            if UnitCanAttack("player", unit) then
                showPercent = true
            elseif UnitIsUnit(unit, "target") then
                showPercent = true
            elseif UnitInParty(unit) or UnitInRaid(unit) then
                showPercent = true
            end

            if showPercent then
                local percent = UnitHealthPercent(
                    unit,
                    true,
                    CurveConstants.ScaleTo100
                )

                if percent then
                    box.text:SetFormattedText(
                        "%.0f%%",
                        percent
                    )

                    box:Show()
                end
            else
                box:Hide()
            end
        else
            box:Hide()
            table.insert(remove, unit)
        end
    end

    for _, unit in ipairs(remove) do
        boxes[unit] = nil
    end
end)


SLASH_HPSIZE1 = "/hpsize"

SlashCmdList["HPSIZE"] = function(msg)
    msg = msg:trim()
    local newSize = tonumber(msg)
    
    if newSize and newSize > 0 then
        size = newSize
        
        
        if HealthPercentDB then
            HealthPercentDB.size = size
        end
        
        print("Successfully changed the font size to: " .. size)
        
        
        local activeUnits = {}
        for unit, box in pairs(boxes) do
            table.insert(activeUnits, unit)
            box:Hide()
        end
        wipe(boxes)
        
        for _, unit in ipairs(activeUnits) do
            if UnitExists(unit) then
                CreateBox(unit)
            end
        end 
    else
        print("The current font size is: " .. size)
        print("Use: /hpsize [number]")
    end
end